G.K. NAV JYOTI PUBLIC SCHOOL – FREE WEBSITE
1. Open index.html in a browser to preview.
2. Replace +91XXXXXXXXXX in index.html with the school's real phone/WhatsApp number.
3. For free hosting, upload index.html to a GitHub repository and enable GitHub Pages.
4. A custom domain can be connected later, but is optional.
